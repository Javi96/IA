package aima.test.core.unit.agent.impl;

import aima.core.agent.AgentProgram;
import aima.core.agent.impl.AbstractAgent;

/**
 * @author Ravi Mohan
 * 
 */
public class MockAgent extends AbstractAgent {
	public MockAgent() {
	}

	public MockAgent(AgentProgram agent) {
		super(agent);
	}
}